export const api = {
  name: 'LojaVirtual-API',
  defaultPort: process.env.PORT ?? 3000,
  db: {
    id: '043577f0-0b22-11ee-be56-0242ac120002',
    dbVersion: 0,
  },
};
